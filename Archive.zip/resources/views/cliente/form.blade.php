<div class="card card-default">
    <div class="card-header">
        <span class="card-title"> Client</span>
    </div>
    <div class="card-body">
        <div class="form-group">
            <label for="nombre_fantasia">Nombre fantasia</label>
            <input type="text" name="nombre_fantasia" id="nombre_fantasia" class="form-control" value="{{ old('nombre_fantasia', $cliente->nombre_fantasia) }}" placeholder="Nombre fantasia">
        </div>
        
        <div class="form-group">
            <label for="contacto">Contacto</label>
            <input type="text" name="contacto" id="contacto" class="form-control" value="{{ old('contacto', $cliente->contacto) }}" placeholder="Contacto">
        </div>
        
        <div class="form-group">
            <label for="email">Email</label>
            <input type="text" name="email" id="email" class="form-control" value="{{ old('email', $user->email) }}" placeholder="Email">
        </div>
        
        <div class="col-12">
            <div class="form-group">
                <label>Descuento</label>
                <select name="descuentos_id" class="form-control" id="descuentos_id">
                    <option value=""> --- Select ---</option>
                    @foreach ($descuentos as $data)
                        <option
                            value="{{ $data->id }}"{{ old('descuentos_id', $cliente->descuentos_id) == $data->id ? 'selected' : '' }}>
                            {{ $data->descripcion }}</option>
                    @endforeach
                </select>
            </div>
        </div>
        {{-- @if (!Auth()->user()->hasrole('clientes')) --}}
            <div class="col-12">
                <div class="form-group">
                    <label>Usuario Aprobador</label>
                    <select name="users_id_aprobo" class="form-control" id="users_id_aprobo">
                        <option value=""> --- Select ---</option>
                        @foreach ($usuarios as $data)
                            <option
                                value="{{ $data->id }}"{{ old('user_id', $cliente->user_id) == $data->id ? 'selected' : '' }}>
                                {{ $data->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label for="fecha_aprobo">Fecha Aprobo</label>
                <input type="text" name="fecha_aprobo" id="fecha_aprobo" class="form-control" value="{{ old('fecha_aprobo', $cliente->fecha_aprobo) }}" placeholder="Fecha Aprobo">
            </div>
            
        {{-- @endif --}}
        <div class="form-group">
            <div class="mb-3">
                <label for="" class="form-label">Formulario</label>
                <input class="form-control" name="form_path" type="file" id="form_path"
                    value="{{ $cliente->form_path }}">
                @if ($cliente->form_path)
                    <p name="form_path_text" class="small mb-1">Valor actual: {{ $cliente->form_path }}</p>
                @else
                    <p class="small mb-1">No se ha cargado ningún archivo.</p>
                @endif
                <h6 class="f-color">"Subir imagen en formato PDF. no superar size 2 mb"<h6>
            </div>
        </div>

    </div>
</div>

<div class="card card-default mt-3">
    <div class="card-header">
        <span class="card-title"> Datos de facturación</span>
    </div>
    <div class="card-body">

        <div class="form-group">
            <label for="razon_social">Razon Social</label>
            <input type="text" name="razon_social" id="razon_social" class="form-control" value="{{ old('razon_social', $datos_factu->razon_social) }}" placeholder="Razon Social">
        </div>
        
        <div class="form-group">
            <label for="cuit">CUIT</label>
            <input type="text" name="cuit" id="cuit" class="form-control" value="{{ old('cuit', $datos_factu->cuit) }}" placeholder="CUIT">
        </div>
        
        <div class="form-group">
            <label for="direccion">Direccion</label>
            <input type="text" name="direccion" id="direccion" class="form-control" value="{{ old('direccion', $datos_factu->direccion) }}" placeholder="Direccion">
        </div>
        
    </div>
</div>

<div class="card card-default mt-3">
    <div class="card-header">
        <span class="card-title"> Formas de pago</span>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-4">
                <div class="form-group">
                    <label for="" class="col-sm-2 col-form-label"></label>
                    <div class="col">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" id="tarjeta" name="tarjeta"
                                {{$cliente->forma_pago_tarjeta == 1 ? 'checked' : ''}}>
                            <label class="form-check-label" for="habilitado">Tarjeta
                                (No/Si)</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <label for="" class="col-sm-2 col-form-label"></label>
                    <div class="col">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" id="cheque"
                                name="cheque" {{$cliente->forma_pago_cheque == 1 ? 'checked' : ''}}>
                            <label class="form-check-label" for="habilitado">Cheque
                                (No/Si)</label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <label for="" class="col-sm-2 col-form-label"></label>
                    <div class="col">
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" role="switch" id="ctacte"
                                name="ctacte" {{$cliente->forma_pago_ctacte == 1 ? 'checked' : ''}}>
                            <label class="form-check-label" for="habilitado">Cuenta corriente
                                (No/Si)</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card card-default mt-3">
    <div class="card-header">
        <span class="card-title">Lugar de entrega</span>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-6">
                <div class="form-group">
                    <label>Sector</label>
                    <select name="sectores_id" class="form-control" id="sectores_id">
                        <option value=""> --- Select ---</option>
                        @foreach ($sectores as $data)
                            <option
                                value="{{ $data->id }}"{{ old('sectores_id', $cli_sector->sectores_id) == $data->id ? 'selected' : '' }}>
                                {{ $data->valor }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-8">
                <div class="form-group">
                    <label for="sector_direccion">Dirección</label>
                    <input type="text" name="sector_direccion" value="{{ $cli_sector->sector_direccion }}" class="form-control" placeholder="Dirección">
                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <label for="sector_cp">Código postal</label>
                    <input type="text" name="sector_cp" value="{{ $cli_sector->sector_cp }}" class="form-control" placeholder="Código postal">
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label for="sector_email">Email</label>
                    <input type="text" name="sector_email" value="{{ $cli_sector->sector_email }}" class="form-control" placeholder="Email">
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label for="sector_telef">Telefonos</label>
                    <input type="text" name="sector_telef" value="{{ $cli_sector->sector_telef }}" class="form-control" placeholder="Telefonos">
                </div>
            </div>
            
        </div>
    </div>

    <div class="card-footer">
        <div class="box-footer mt-3">
            <button type="submit" class="btn btn-primary">{{ __('Submit') }}</button>
        </div>
    </div>
</div>
