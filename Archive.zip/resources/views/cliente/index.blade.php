@extends('layouts.main')

@section('template_title')
    Cliente
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                {{ __('Cliente') }}
                            </span>

                             <div class="float-right">
                                <a href="{{ route('clientes.create', 'abm') }}" class="btn btn-primary btn-sm float-right"  data-placement="left">
                                  {{ __('Create New') }}
                                </a>
                              </div>
                        </div>
                    </div>
                    @if ($message = Session::get('success'))
                        <div class="alert alert-success">
                            <p>{{ $message }}</p>
                        </div>
                    @endif

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
										<th>Contacto</th>
										<th>Razon Social</th>
										<th>Descuentos Id</th>
										<th>Users Id Aprobo</th>
										<th>Fecha Aprobo</th>
                                        <th>Deshabilitado</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($clientes as $cliente)
                                        <tr>
                                            <td>{{ ++$i }}</td>
                                            
											<td>{{ $cliente->contacto }}</td>
											<td>{{ $cliente->nombre_fantasia }}</td>
											<td>{{ $cliente->descuentos_id }}</td>
											<td>{{ $cliente->users_id_aprobo }}</td>
											<td>{{ $cliente->fecha_aprobo }}</td>
                                            <td text-center align-middle>
                                                        @if($cliente->Deshabilitado == 0)  
                                                            <i class="text-body ci-security-check c-green"></i> 
                                                        @else 
                                                            <i class="text-body ci-security-close c-red"></i>
                                                        @endif
                                            </td>
                                            <td>
                                                <form action="{{ route('clientes.destroy',$cliente->id) }}" method="POST">
                                                    <a class="btn btn-sm-80 btn-primary " href="{{ route('clientes.show',$cliente->id) }}"><i class="text-body ci-eye size-icon"></i> </a>
                                                    <a class="btn btn-sm-80 btn-success" href="{{ route('clientes.edit',$cliente->id) }}"><i class="text-body ci-edit-alt size-icon"></i> </a>
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm-80"><i class="text-body ci-trash size-icon"></i> </button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                {!! $clientes->links() !!}
            </div>
        </div>
    </div>
@endsection
