@extends('layouts.main')

@section('content')
    @livewire('allshop')
@endsection
