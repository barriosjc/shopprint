@extends('layouts.init')

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card mt-5">
                    <div class="card-header bg-secondary">
                        <ul class="nav nav-tabs card-header-tabs" role="tablist">
                            <li class="nav-item"><a class="nav-link fw-medium active" href="#" data-bs-toggle="tab"
                                    role="tab" aria-selected="true"><i class="ci-add-user me-2 mt-n1"></i>Sign up</a>
                            </li>
                        </ul>
                    </div>
                    <div class="card-body">

                        @includeif('utiles.alerts')

                        <form method="POST" class="needs-validation" autocomplete="off" novalidate id="signin-tab"
                            action="{{ route('clientes.store', 'register') }}" role="form" enctype="multipart/form-data">
                            @csrf
                            <div class="col-md-12 pt-4 mt-3 mt-md-0">

                                <div class="card-body">
                                    <div class="tab-content">
                                        <div class="tab-pane fade show active" id="result1" role="tabpanel">
                                            <div class="steps steps-dark mt-3"><a class="step-item active current"
                                                    href="#" id="a-step1">
                                                    <div id="step1" class="step-progress"><span
                                                            class="step-count">1</span></div>
                                                    <div class="step-label"><i class="ci-add-user"></i>Step 1</div>
                                                </a><a class="step-item" href="#" id="a-step2">
                                                    <div id="step2" class="step-progress"><span
                                                            class="step-count">2</span></div>
                                                    <div class="step-label"><i class="ci-document"></i>Step 2</div>
                                                </a><a class="step-item" href="#" id="a-step3">
                                                    <div id="step3" class="step-progress"><span
                                                            class="step-count">3</span></div>
                                                    <div class="step-label"><i class="ci-check-circle"></i>Step 3</div>
                                                </a>
                                            </div>
                                        </div>
                                        <br>
                                    </div>
                                </div>

                                {{-- <div class="card-body">
                                    <div class="tab-content">
                                        <div class="tab-pane fade show active" id="result2" role="tabpanel">
                                            <div class="steps steps-dark mt-3"><a class="step-item active" href="#">
                                                    <div class="step-progress"><span class="step-count">1</span></div>
                                                    <div class="step-label"><i class="ci-add-user"></i>Step 1</div>
                                                </a><a class="step-item active current" href="#">
                                                    <div class="step-progress"><span class="step-count">2</span></div>
                                                    <div class="step-label"><i class="ci-document"></i>Step 2</div>
                                                </a><a class="step-item" href="#">
                                                    <div class="step-progress"><span class="step-count">3</span></div>
                                                    <div class="step-label"><i class="ci-check-circle"></i>Step 3</div>
                                                </a>
                                            </div>
                                        </div><br>



                                    </div>
                                </div>

                                <div class="card-body">
                                    <div class="tab-content">
                                        <div class="tab-pane fade show active" id="result3" role="tabpanel">
                                            <div class="steps steps-dark mt-3"><a class="step-item active" href="#">
                                                    <div class="step-progress"><span class="step-count">1</span></div>
                                                    <div class="step-label"><i class="ci-add-user"></i>Step 1</div>
                                                </a><a class="step-item active" href="#">
                                                    <div class="step-progress"><span class="step-count">2</span></div>
                                                    <div class="step-label"><i class="ci-document"></i>Step 2</div>
                                                </a><a class="step-item active current" href="#">
                                                    <div class="step-progress"><span class="step-count">3</span></div>
                                                    <div class="step-label"><i class="ci-check-circle"></i>Step 3</div>
                                                </a>
                                            </div>
                                        </div><br>



                                    </div>
                                </div> --}}

                                <div class="card-body">
                                    @php($currentTab = 1)
                                    <div class="tab-content" id="cardTabContent">
                                        <div class="tab-pane py-5 py-xl-3 fade {{ $currentTab == 1 ? 'show active' : '' }}"
                                            id="wizard1" role="tabpanel" aria-labelledby="wizard1-tab">
                                            <div class="row justify-content-center">

                                                <label class="form-label fs-5">PERSONAL INFORMATION</label>
                                                <div class="col-sm-6">
                                                    <label class="form-label" for="reg-fn">Fantasy Name</label>
                                                    <input class="form-control" type="text" required id="nombre_fantasia"
                                                        name="nombre_fantasia"
                                                        value="{{ old('nombre_fantasia', $cliente->nombre_fantasia) }}">
                                                    <div class="invalid-feedback">Please enter your fantasy name!</div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label class="form-label" for="reg-ln">Contact</label>
                                                    <input class="form-control" type="text" required id="contacto"
                                                        name="contacto" value="{{ old('contacto', $cliente->contacto) }}">
                                                    <div class="invalid-feedback">Please enter your name!</div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label class="form-label" for="reg-email">E-mail Address</label>
                                                    <input class="form-control" type="email" required id="email"
                                                        name="email" value="{{ old('email', $cliente->email) }}">
                                                    <div class="invalid-feedback">Please enter valid email address!</div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <label for="" class="form-label">Formulario</label>
                                                        <input class="form-control" name="form_path" type="file"
                                                            id="form_path" required>
                                                        {{-- @if ($cliente->form_path) 
                                                            <label name="form_path_text" class="small mb-1">Valor actual: {{ $cliente->form_path }}</label>
                                                        @else
                                                            <label class="small mb-1">No se ha cargado ningún archivo.</label>
                                                        @endif --}}
                                                        <h6 class="f-color">"Subir imagen en formato PDF. no superar size 2
                                                            mb"<h6>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="tab-pane py-5 py-xl-3 fade {{ $currentTab == 2 ? 'show active' : '' }} "
                                            id="wizard2" role="tabpanel" aria-labelledby="wizard2-tab">
                                            <div class="row justify-content-center">
                                                <label class="form-label fs-5">ADDRESSES INFORMATION</label>
                                            </div>
                                            <div class="row justify-content-center">
                                                <div class="col-sm-6">
                                                    <label class="form-label" for="reg-fn">Razon social</label>
                                                    <input class="form-control" type="text" required id="razon_social"
                                                        name="razon_social"
                                                        value="{{ old('razon_social', $cliente->razon_social) }}">
                                                    <div class="invalid-feedback">Please enter your razón social!</div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label class="form-label" for="reg-ln">TAX id</label>
                                                    <input class="form-control" type="text" required id="cuit"
                                                        name="cuit" value="{{ old('cuit', $cliente->cuit) }}">
                                                    <div class="invalid-feedback">Please enter your TAX id!</div>
                                                </div>
                                                <div class="col-sm-8">
                                                    <label class="form-label" for="reg-ln">Address</label>
                                                    <input class="form-control" type="text" id="direccion"
                                                        name="direccion"
                                                        value="{{ old('direccion', $cliente->direccion) }}">
                                                    <div class="invalid-feedback">Please enter your address</div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <label class="form-label" for="reg-ln">Zip Code</label>
                                                    <input class="form-control" type="text" id="cp"
                                                        name="cp" value="{{ old('cp', $cliente->cp) }}">
                                                    <div class="invalid-feedback">Please enter your zip code</div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="tab-pane py-5 py-xl-3 fade {{ $currentTab == 3 ? 'show active' : '' }}"
                                            id="wizard3" role="tabpanel" aria-labelledby="wizard3-tab">
                                            <div class="row justify-content-center">
                                                <label class="form-label fs-5">OTHER INFORMATION</label>
                                                <div class="col-sm-4">
                                                    <div class="form-group">
                                                        <label class="form-label">Sector</label>
                                                        <select name="sectores_id" class="form-control" id="sectores_id">
                                                            <option value=""> --- Select ---</option>
                                                            @foreach ($sectores as $data)
                                                                <option
                                                                    value="{{ $data->id }}"{{ old('sectores_id', $cli_sector->sectores_id) == $data->id ? 'selected' : '' }}>
                                                                    {{ $data->valor }}</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                    <div class="invalid-feedback">Seleccione el sector de entrega!</div>
                                                </div>
                                                <div class="col-sm-8">
                                                    <label class="form-label" for="reg-fn">Address</label>
                                                    <input class="form-control" type="text" required
                                                        id="sector_direccion" name="sector_direccion"
                                                        value="{{ old('sector_direccion', $cliente->sector_direccion) }}">
                                                    <div class="invalid-feedback">Please enter your Address!</div>
                                                </div>
                                                <div class="col-sm-4">
                                                    <label class="form-label" for="reg-fn">Zip Code</label>
                                                    <input class="form-control" type="text" id="sector_cp"
                                                        name="sector_cp"
                                                        value="{{ old('sector_cp', $cliente->sector_cp) }}">
                                                    <div class="invalid-feedback">Please enter your zip code!</div>
                                                </div>
                                                <div class="col-sm-8">
                                                    <label class="form-label" for="reg-fn">Email</label>
                                                    <input class="form-control" type="email" id="sector_email"
                                                        name="sector_email"
                                                        value="{{ old('sector_email', $cliente->sector_email) }}">
                                                    <div class="invalid-feedback">Please enter your Email!</div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <label class="form-label" for="reg-fn">Phones</label>
                                                    <input class="form-control" type="text" required id="sector_telef"
                                                        name="sector_telef"
                                                        value="{{ old('sector_telef', $cli_sector->sector_telef) }}">
                                                    <div class="invalid-feedback">Please enter your phone!</div>
                                                </div>

                                                <div class="col-12 text-end">
                                                    <button class="btn btn-primary" type="submit"><i
                                                            class="ci-user me-2 ms-n1"></i>Sign Up</button>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            var step1 = document.getElementById("step1");
            var step2 = document.getElementById("step2");
            var step3 = document.getElementById("step3");
            var a_step1 = document.getElementById("a-step1");
            var a_step2 = document.getElementById("a-step2");
            var a_step3 = document.getElementById("a-step3");
            var wizard1 = document.getElementById("wizard1");
            var wizard2 = document.getElementById("wizard2");
            var wizard3 = document.getElementById("wizard3");

            // Agregar un evento de clic al elemento con id "step1"

            function remove() {
                wizard1.classList.remove("show", "active");
                wizard2.classList.remove("show", "active");
                wizard3.classList.remove("show", "active");
            }

            step1.addEventListener("click", function() {
                remove()
                wizard1.classList.add("show", "active");
                a_step1.classList.add("active", "current");
                a_step2.classList.remove("active", "current");
                a_step3.classList.remove("active", "current");
            });
            step2.addEventListener("click", function() {
                remove()
                wizard2.classList.add("show", "active");
                a_step1.classList.add("active", "current");
                a_step2.classList.add("active", "current");
                a_step3.classList.remove("active", "current");

            });
            step3.addEventListener("click", function() {
                remove()
                wizard3.classList.add("show", "active");
                a_step1.classList.add("active", "current");
                a_step2.classList.add("active", "current");
                a_step3.classList.add("active", "current");
            });
        });
    </script>
@endsection
