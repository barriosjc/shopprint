
@extends('seguridad.usuario.profile')

@section('profield')
    @include('seguridad.usuario.perfil_data')
@endsection
