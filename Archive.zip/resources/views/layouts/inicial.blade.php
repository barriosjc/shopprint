@extends('layouts.main')

@section('content')
<section class="tns-carousel tns-controls-lg mb-4 mb-lg-5">
    <div class="tns-carousel-inner" data-carousel-options="{&quot;mode&quot;: &quot;gallery&quot;, &quot;responsive&quot;: {&quot;0&quot;:{&quot;nav&quot;:true, &quot;controls&quot;: false},&quot;992&quot;:{&quot;nav&quot;:false, &quot;controls&quot;: true}}}">
      <!-- Item-->
      <div class="px-lg-5" style="background-color: #161c36;">
        <div class="d-lg-flex justify-content-between align-items-center ps-lg-4"><img class="d-block order-lg-2 me-lg-n5 flex-shrink-0" src={{ asset("img/home/hero-slider/home-banner1.jpg") }} alt="Women Sportswear">
          <div class="position-relative mx-auto py-5 px-4 mb-lg-5 order-lg-1" style="max-width: 42rem; z-index: 10;">
            <div class="pb-lg-5 mb-lg-5 text-center text-lg-start text-lg-nowrap">
              <h3 class="h2 text-light fw-light pb-1 from-bottom">Retactable Banners</h3>
              <h2 class=" display-5 from-bottom delay-1" style="color: #dd423b;">20% Discount</h2>
              <p class="fs-lg text-light pb-3 from-bottom delay-2">Vinyls, Canvas, Mesh...</p>
              <div class="d-table scale-up delay-4 mx-auto mx-lg-0"><a class="btn btn-primary" href="shop-grid-ls.html">Shop Now<i class="ci-arrow-right ms-2 me-n1"></i></a></div>
            </div>
          </div>
        </div>
      </div>
      <!-- Item-->
      <div class="px-lg-5" style="background-color: #0d172d;">
        <div class="d-lg-flex justify-content-between align-items-center ps-lg-4"><img class="d-block order-lg-2 me-lg-n5 flex-shrink-0" src={{ asset("img/home/hero-slider/home-banner2.jpg") }} alt="Summer Collection">
          <div class="position-relative mx-auto  py-5 px-4 mb-lg-5 order-lg-1" style="max-width: 42rem; z-index: 10;">
            <div class="pb-lg-5 mb-lg-5 text-center text-lg-start text-lg-nowrap">
              <h3 class="h2 text-light fw-light pb-1 from-start">High Quality, Vivid Colors</h3>
              <h2 class="display-5 from-start delay-1" style="color: #dd423b;">Promotional Discounts</h2>
              <p class="fs-lg text-light pb-3 from-start delay-2">In Rigid products</p>
              <div class="d-table scale-up delay-4 mx-auto mx-lg-0"><a class="btn btn-primary" href="shop-grid-ls.html">Shop Now<i class="ci-arrow-right ms-2 me-n1"></i></a></div>
            </div>
          </div>
        </div>
      </div>          
    </div>
  </section>
  <!-- Products grid (Trending products)-->
  <section class="container pt-4 mt-md-4 mb-5">
    <h2 class="h3 text-center mb-3">Categories</h2>
    <div class="row pt-4">
    
      <div class="col-md-4 col-sm-6 mb-grid-gutter">
        <div class="card border-0 shadow"><a href="#"><img class="card-img-top" src={{ asset("img/categories/categ-banner.jpg") }} alt="Orlando"></a>
          <div class="card-body">
            <h6>Vinyl, Canvas, Poster, Fabric, Mesh</h6>
            
          </div>
        </div>
      </div>
      <div class="col-md-4 col-sm-6 mb-grid-gutter">
        <div class="card border-0 shadow"><a href="#"><img class="card-img-top" src={{ asset("img/categories/categ-rigid.jpg") }} alt="Orlando"></a>
          <div class="card-body">
            <h6>Coroplast, Foamcore, Styrene</h6>
            
          </div>
        </div>
      </div>
      <div class="col-md-4 col-sm-6 mb-grid-gutter">
        <div class="card border-0 shadow"><a href="#"><img class="card-img-top" src={{ asset("img/categories/categ-adhesive.jpg") }} alt="Orlando"></a>
          <div class="card-body">
            <h6>Window, Statig Ling, Textured...</h6>
            
          </div>
        </div>
      </div>
        <div class="col-md-4 col-sm-6 mb-grid-gutter">
        <div class="card border-0 shadow"><img class="card-img-top" src={{ asset("img/categories/categ-magnets.jpg") }} alt="Orlando">
          <div class="card-body">
            <h6>.030 Magnetic Material, Fridge...</h6>
            
          </div>
        </div>
      </div>
        <div class="col-md-4 col-sm-6 mb-grid-gutter">
        <div class="card border-0 shadow"><img class="card-img-top" src={{ asset("img/categories/categ-banner-stand.jpg") }} alt="Orlando">
          <div class="card-body">
            <h6>Pull up Banner</h6>
            
          </div>
        </div>
      </div>
        <div class="col-md-4 col-sm-6 mb-grid-gutter">
        <div class="card border-0 shadow"><img class="card-img-top" src={{ asset("img/categories/categ-clothing.jpg") }} alt="Orlando">
          <div class="card-body">
            <h6>DTF</h6>
            
          </div>
        </div>
      </div>
        <div class="col-md-4 col-sm-6 mb-grid-gutter">
        <div class="card border-0 shadow"><img class="card-img-top" src={{ asset("img/categories/categ-stickers.jpg") }} alt="Orlando">
          <div class="card-body">
            <h6>Stickers, Roll Labels</h6>
            
          </div>
        </div>
      </div>
        <div class="col-md-4 col-sm-6 mb-grid-gutter">
        <div class="card border-0 shadow"><img class="card-img-top" src={{ asset("img/categories/categ-misc.jpg") }} alt="Orlando">
          <div class="card-body">
            <h6>Sample Kit, Otras</h6>
            
          </div>
        </div>
      </div>
    </div>
  </section>
@endsection