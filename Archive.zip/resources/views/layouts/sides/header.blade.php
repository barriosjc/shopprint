<header class="bg-dark navbar-sticky">
    <div class="navbar navbar-expand-lg navbar-dark">
        <div class="container"><a class="navbar-brand d-none d-sm-block me-4 order-lg-1" href="{{ route('home') }}">
            <img src={{ asset('template/img/logo-top-imprint-signs.png') }} width="140" alt="Imprint Signs"></a>
                    <a class="navbar-brand d-sm-none me-2 order-lg-1" href="{{ route('home') }}" style="min-width: 4.625rem;">
            <img src={{ asset('template/img/logo-top-imprint-signs.png') }} width="140" alt="Cartzilla"></a>
            <div class="navbar-toolbar d-flex align-items-center order-lg-3">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarCollapse"><span class="navbar-toggler-icon"></span></button>
                <a class="navbar-tool ms-1 me-n1" href="#signin-modal" data-bs-toggle="modal"><span
                        class="navbar-tool-tooltip">Account</span>
                    <div class="navbar-tool-icon-box"><i class="navbar-tool-icon ci-user"></i></div>
                </a>
                <div class="navbar-tool dropdown ms-3"><a class="navbar-tool-icon-box bg-secondary dropdown-toggle"
                        href="#"><span class="navbar-tool-label">{{Cart::getContent()->count()}}</span><i class="navbar-tool-icon ci-cart"></i></a>
                        <div class="dropdown-menu"  aria-labelledby="navbarDropdownMenuLink">
                            <h6 class="dropdown-header">Dropdown header</h6>
                            <a href="{{ route('front.profile') }} " class="dropdown-item">Profile info</a>
                            <a href="{{ route('cart.index') }}" class="dropdown-item">Carrito</a>
                            <div class="dropdown-divider"></div>
                            {{-- <a href="#" class="dropdown-item">Log Out</a> --}}
                            <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                        document.getElementById('logout-form').submit();">
                            <i data-feather="log-out"></i>                                                        
                                {{ __('Logout') }}
                            </a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                @csrf
                            </form>
                        </div>
                                            <!-- Cart dropdown-->
                </div>
            </div>

            <!-- Dropdown example 2 -->


            <div class="collapse navbar-collapse me-auto order-lg-2" id="navbarCollapse">
                <!-- Search-->
                <div class="input-group d-lg-none my-3"><i
                        class="ci-search position-absolute top-50 start-0 translate-middle-y text-muted fs-base ms-3"></i>
                    <input class="form-control rounded-start" type="text" placeholder="Search for products">
                </div>
                <!-- Primary menu-->
                <ul class="navbar-nav">
                    <li class="nav-item text-center"><a class="nav-link" href="{{ route('productos.list', 1) }}">
                            <div style=" display: flex; justify-content: center; padding-bottom: 5px;"><img
                                    src={{ asset('template/img/icons/banner.png') }} alt="" /></div>Banner
                        </a>

                    </li>
                    <li class="nav-item text-center"><a class="nav-link" href="{{ route('productos.list', 3) }}">
                            <div style=" display: flex; justify-content: center; padding-bottom: 5px;"><img
                                    src={{ asset('template/img/icons/rigid.png') }} alt="" /></div>Rigid
                        </a>

                    </li>
                    <li class="nav-item text-center"><a class="nav-link" href="{{ route('productos.list', 4) }}">
                            <div style=" display: flex; justify-content: center; padding-bottom: 5px;"><img
                                    src={{ asset('template/img/icons/adhesive.png') }} alt="" /></div>Adhesive
                        </a>

                    </li>
                    <li class="nav-item text-center"><a class="nav-link" href="{{ route('productos.list', 2) }}">
                            <div style=" display: flex; justify-content: center; padding-bottom: 5px;"><img
                                    src={{ asset('template/img/icons/magnets.png') }} alt="" /></div>Magnets
                        </a>

                    </li>
                    <li class="nav-item text-center"><a class="nav-link" href="{{ route('productos.list', 5) }}">
                            <div style=" display: flex; justify-content: center; padding-bottom: 5px;"><img
                                    src={{ asset('template/img/icons/banner-stand.png') }} alt="" /></div>Banner
                            Stand
                        </a>

                    </li>
                    <li class="nav-item text-center"><a class="nav-link" href="{{ route('productos.list', 6) }}">
                            <div style=" display: flex; justify-content: center; padding-bottom: 5px;"><img
                                    src={{ asset('template/img/icons/clothing.png') }} alt="" /></div>Clothing
                        </a>

                    </li>
                    <li class="nav-item text-center"><a class="nav-link" href="{{ route('productos.list', 7) }}">
                            <div style=" display: flex; justify-content: center; padding-bottom: 5px;"><img
                                    src={{ asset('template/img/icons/sticker.png') }} alt="" /></div>
                            Stickers/Labels
                        </a>

                    </li>
                    <li class="nav-item text-center"><a class="nav-link" href="{{ route('productos.list', 8) }}">
                            <div style=" display: flex; justify-content: center; padding-bottom: 5px;"><img
                                    src={{ asset('template/img/icons/misc.png') }} alt="" /></div>Misc
                        </a>

                    </li>

                </ul>
            </div>
        </div>
    </div>


</header>
