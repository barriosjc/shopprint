{{-- <section class="container pt-4 mt-md-4 mb-5">
    <h2 class="h3 text-center mb-3">Categories</h2>
    <div class="row pt-4">

        <div class="col-md-4 col-sm-6 mb-grid-gutter">
            <div class="card border-0 shadow"><a href="#"><img class="card-img-top"
                        src={{ asset('template/img/categories/categ-banner.jpg') }} alt="Orlando"></a>
                <div class="card-body">
                    <h6>Vinyl, Canvas, Poster, Fabric, Mesh</h6>

                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 mb-grid-gutter">
            <div class="card border-0 shadow"><a href="#"><img class="card-img-top"
                        src={{ asset('template/img/categories/categ-rigid.jpg') }} alt="Orlando"></a>
                <div class="card-body">
                    <h6>Coroplast, Foamcore, Styrene</h6>

                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 mb-grid-gutter">
            <div class="card border-0 shadow"><a href="#"><img class="card-img-top"
                        src={{ asset('template/img/categories/categ-adhesive.jpg') }} alt="Orlando"></a>
                <div class="card-body">
                    <h6>Window, Statig Ling, Textured...</h6>

                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 mb-grid-gutter">
            <div class="card border-0 shadow"><img class="card-img-top"
                    src={{ asset('template/img/categories/categ-magnets.jpg') }} alt="Orlando">
                <div class="card-body">
                    <h6>.030 Magnetic Material, Fridge...</h6>

                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 mb-grid-gutter">
            <div class="card border-0 shadow"><img class="card-img-top"
                    src={{ asset('template/img/categories/categ-banner-stand.jpg') }} alt="Orlando">
                <div class="card-body">
                    <h6>Pull up Banner</h6>

                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 mb-grid-gutter">
            <div class="card border-0 shadow"><img class="card-img-top"
                    src={{ asset('template/img/categories/categ-clothing.jpg') }} alt="Orlando">
                <div class="card-body">
                    <h6>DTF</h6>

                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 mb-grid-gutter">
            <div class="card border-0 shadow"><img class="card-img-top"
                    src={{ asset('template/img/categories/categ-stickers.jpg') }} alt="Orlando">
                <div class="card-body">
                    <h6>Stickers, Roll Labels</h6>

                </div>
            </div>
        </div>
        <div class="col-md-4 col-sm-6 mb-grid-gutter">
            <div class="card border-0 shadow"><img class="card-img-top"
                    src={{ asset('template/img/categories/categ-misc.jpg') }} alt="Orlando">
                <div class="card-body">
                    <h6>Sample Kit, Otras</h6>

                </div>
            </div>
        </div>
    </div>
</section>

<section class="container-fluid pt-grid-gutter">
    <div class="row">

        <div class="col-xl-4 col-sm-6 mb-grid-gutter">
            <div class="card h-100">
                <div class="card-body text-center"><i class="ci-time h3 mt-2 mb-4 text-primary"></i>
                    <h3 class="h6 mb-3">Working hours</h3>
                    <ul class="list-unstyled fs-sm text-muted mb-0">
                        <li>Mon - Fri: 10AM - 7PM</li>
                        <li class="mb-0">Sta: 11AM - 5PM</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-sm-6 mb-grid-gutter">
            <div class="card h-100">
                <div class="card-body text-center"><i class="ci-phone h3 mt-2 mb-4 text-primary"></i>
                    <h3 class="h6 mb-3">Phone numbers</h3>
                    <ul class="list-unstyled fs-sm mb-0">
                        <li><span class="text-muted me-1">For customers:</span><a class="nav-link-style"
                                href="tel:+108044357260">+1 (080) 44 357 260</a></li>
                        <li class="mb-0"><span class="text-muted me-1">Tech support:</span><a
                                class="nav-link-style" href="tel:+100331697720">+1 00 33 169 7720</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="col-xl-4 col-sm-6 mb-grid-gutter">
            <div class="card h-100">
                <div class="card-body text-center"><i class="ci-mail h3 mt-2 mb-4 text-primary"></i>
                    <h3 class="h6 mb-3">Email addresses</h3>
                    <ul class="list-unstyled fs-sm mb-0">
                        <li><span class="text-muted me-1">For customers:</span><a class="nav-link-style"
                                href="mailto:+108044357260">customer@example.com</a></li>
                        <li class="mb-0"><span class="text-muted me-1">Tech support:</span><a
                                class="nav-link-style"
                                href="mailto:support@example.com">support@example.com</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section> --}}