
@if(session('error_msg') || $errors->any())
    <div class="position-fixed top-0 end-0 p-3">
        <div id="toast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-primary text-white">
                <i class="ci-bell me-2"></i>
                <strong class="fw-medium me-auto">Message</strong>
                <button type="button" class="btn-close btn-close-white ms-2" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            @if(session('error_msg'))
                <div class="toast-body text-primary">
                    {{ session('error_msg') }}
                </div>
            @endif
            @if ($errors->any())
                <div class="toast-body text-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>
                                {{ $error }}
                            </li>
                        @endforeach
                    </ul>
                </div>
            @endif
        </div>
    </div>
@endif

@if(session('success_msg') || $errors->any())
    <div class="position-fixed top-0 end-0 p-3">
        <div id="toast" class="toast" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header bg-info text-white">
                <i class="ci-bell me-2"></i>
                <strong class="fw-medium me-auto">Message</strong>
                <button type="button" class="btn-close btn-close-white ms-2" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            @if(session('success_msg'))
                <div class="toast-body text-info">
                    {{ session('success_msg') }}
                </div>
            @endif
            @if ($errors->any())
                <div class="toast-body text-info">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>
                                {{ $error }}
                            </li>
                        @endforeach
                    </ul>
                </div>
            @endif
        </div>
    </div>
@endif

<script>
    // Muestra el Toast si existe un mensaje
    document.addEventListener('DOMContentLoaded', function () {
        @if(session('success_msg') || $errors->any())
            var toast = new bootstrap.Toast(document.getElementById('toast'));
            toast.show();
        @endif
        @if(session('error_msg') || $errors->any())
            var toast = new bootstrap.Toast(document.getElementById('toast'));
            toast.show();
        @endif
    });
</script>