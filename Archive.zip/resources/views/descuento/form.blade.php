<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <label for="descripcion">Descripcion</label>
            <input type="text" name="descripcion" id="descripcion" class="form-control" value="{{ old('descripcion', $descuento->descripcion) }}" placeholder="Descripcion">
        </div>
        
        <div class="form-group">
            <label for="porcentaje">Porcentaje</label>
            <input type="text" name="porcentaje" id="porcentaje" class="form-control" value="{{ old('porcentaje', $descuento->porcentaje) }}" placeholder="Porcentaje">
        </div>
        
        <div class="form-group">
            <label for="orden">Orden</label>
            <input type="text" name="orden" id="orden" class="form-control" value="{{ old('orden', $descuento->orden) }}" placeholder="Orden">
        </div>
        
        <div class="form-group">
            <label for="vigencia_desde">Vigencia Desde</label>
            <input type="text" name="vigencia_desde" id="vigencia_desde" class="form-control" value="{{ old('vigencia_desde', $descuento->vigencia_desde) }}" placeholder="Vigencia Desde">
        </div>
        
        <div class="form-group">
            <label for="vigencia_hasta">Vigencia Hasta</label>
            <input type="text" name="vigencia_hasta" id="vigencia_hasta" class="form-control" value="{{ old('vigencia_hasta', $descuento->vigencia_hasta) }}" placeholder="Vigencia Hasta">
        </div>        

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">{{ __('Submit') }}</button>
    </div>
</div>