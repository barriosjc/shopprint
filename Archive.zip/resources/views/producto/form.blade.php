
<div class="box box-info padding-1">
    <div class="box-body">
        <input id="categorias_id" name="categorias_id" type="hidden" value="{{ $categorias->id }}" />
        <input id="productos_id" name="productos_id" type="hidden" value="{{ $producto->id }}" />
        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" id="nombre" class="form-control" value="{{ old('nombre', $producto->nombre) }}" placeholder="nombre">
        </div>
        <div class="form-group">
            <label for="detalle">Detalle</label>
            <input type="text" name="detalle" id="detalle" class="form-control" value="{{ old('detalle', $producto->detalle) }}" placeholder="detalle">
        </div>
        <div class="row">
            <div class="col-6">
                <div class="form-group">
                    <label for="precio_compra">Precio compra</label>
                    <input type="text" name="precio_compra" id="precio_compra" class="form-control" value="{{ old('precio_compra', $producto->precio_compra) }}" placeholder="Precio Compra">
                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <label for="precio_venta">Precio venta</label>
                    <input type="text" name="precio_venta" id="precio_venta" class="form-control" value="{{ old('precio_venta', $producto->precio_venta) }}" placeholder="Precio Venta">
                </div>
            </div>
        </div>        
        <div class="col-6">
            <div class="form-group">
                <label for="" class="col-sm-2 col-form-label"></label>
                <div class="col">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="destacado" name="destacado"
                            {{ !$producto->destacado ?? checked }}>
                        <label class="form-check-label" for="habilitado">destacado
                            (No/Si)</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="form-group">
                <label for="" class="col-sm-2 col-form-label"></label>
                <div class="col">
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" role="switch" id="habilitado" name="habilitado"
                            {{ !$producto->habilitado ?? checked }}>
                        <label class="form-check-label" for="habilitado">Habilitado
                            (No/Si)</label>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12">
            <div class="form-group">
                <label>Descuento</label>
                <select name="descuentos_id" class="form-control" id="descuentos_id">
                    <option value=""> --- Select ---</option>
                    @foreach ($descuentos as $data)
                        <option
                            value="{{ $data->id }}"{{ old('descuentos_id', $producto->descuentos_id) == $data->id ? 'selected' : '' }}>
                            {{ $data->descripcion }}</option>
                    @endforeach
                </select>
            </div>
        </div>
    </div>
{{-- @dd($productos_adicional_def) --}}
    <div class="row">
        <div class="horizontal-inputs">
            @foreach ($productos_adicional_def as $item)
                @php($valor = "")
                <div class="form-group col-sm-{{ $item->cant_columnas }} pe-3">
                    <label for="orden" class="col-form-label">{{ $item->definicion_descripcion }}</label>
                    @if ($productos_adicional_val)
                        @foreach ($productos_adicional_val as $campo)
                            @if ($campo->adicional_descripcion == $item->nombre_campo)
                                @php($valor = isset($campo->adicional_valor) ? $campo->adicional_valor : '')
                            @endif
                        @endforeach
                    @endif
                    <input type="text" class="form-control" id="{{ $item->nombre_campo }}"
                        name="adic[{{ $item->nombre_campo }}]" placeholder="" value="{{ $valor }}">

                </div>
            @endforeach
        </div>
    </div>

    <div class="row">
        <div class="box-footer mt20 pt-4">
            <button type="submit" class="btn btn-primary">{{ __('Submit') }}</button>
            @if ($producto->id)
                <a href="{{ route('productos.fotos.create', $producto->id) }}" class="btn btn-warning float-right"
                    data-placement="left">
                    {{ __('Product photos') }}
                </a>
            @endif
        </div>
    </div>

</div>
