@extends('layouts.main')

@section('template_title')
    Producto
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                {{ __('Producto') }}
                            </span>

                             <div class="float-right">
                                <a href="{{ route('productos.create', $categorias_id) }}" class="btn btn-primary btn-sm float-right"  data-placement="left">
                                  {{ __('Create New') }}
                                </a>
                              </div>
                        </div>
                    </div>
                    @if ($message = Session::get('success'))
                        <div class="alert alert-success">
                            <p>{{ $message }}</p>
                        </div>
                    @endif

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
										<th>nombre</th>
										<th>Precio Compra</th>
										<th>Precio Venta</th>
										<th>Destacado</th>
										<th>Habilitado</th>
										<th>Descuentos Id</th>
										<th>Categorias Id</th>
                                        <th>     
                                            <div class="float-right">
                                                Valores
                                            </div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($productos as $producto)
                                        <tr>
                                            <td>{{ ++$i }}</td>
                                            
											<td>{{ $producto->nombre }}</td>
											<td>{{ $producto->precio_compra }}</td>
											<td>{{ $producto->precio_venta }}</td>
											<td>{{ $producto->destacado }}</td>
                                            <td text-center align-middle>
                                                @if($producto->Deshabilitado == 0)  
                                                    <i class="text-body ci-security-check c-green"></i> 
                                                @else 
                                                    <i class="text-body ci-security-close c-red"></i>
                                                @endif
                                            </td>
											<td>{{ $producto->descuentos_id }}</td>
											<td>{{ $producto->categorias_id }}</td>

                                            <td>
                                                <form action="{{ route('productos.destroy',$producto->id) }}" method="POST">
                                                    <a class="btn btn-sm-80 btn-primary " href="{{ route('productos.show',$producto->id) }}"><i class="text-body ci-eye size-icon"></i></a>
                                                    <a class="btn btn-sm-80 btn-success" href="{{ route('productos.edit',$producto->id) }}"><i class="text-body ci-edit-alt size-icon"></i></a>
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger btn-sm-80"><i class="text-body ci-trash size-icon"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        {{ $productos->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
