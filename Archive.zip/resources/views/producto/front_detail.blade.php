@extends('layouts.main')

@section('content')

    <body class="handheld-toolbar-enabled">
        <!-- Sign in / sign up modal-->

        <main class="page-wrapper">
            <!-- Page Title-->
            <div class="page-title-overlap bg-dark pt-4">
                <div class="container d-lg-flex justify-content-between py-2 py-lg-3">
                    <div class="order-lg-2 mb-3 mb-lg-0 pt-lg-2">
                        <nav aria-label="breadcrumb">
                            <ol
                                class="breadcrumb breadcrumb-light flex-lg-nowrap justify-content-center justify-content-lg-start">
                                <li class="breadcrumb-item"><a class="text-nowrap" href="index.html"><i
                                            class="ci-home"></i>Home</a></li>
                                <li class="breadcrumb-item text-nowrap"><a
                                        href="{{ route('productos.list', $categorias->id) }}">Product List</a> </li>
                                <li class="breadcrumb-item text-nowrap active" aria-current="page">Product</li>
                            </ol>
                        </nav>
                    </div>
                    <div class="order-lg-1 pe-lg-4 text-center text-lg-start">
                        <h1 class="h3 text-light mb-0">{{ $categorias->descripcion }}</h1>
                    </div>
                </div>
            </div>
            <div class="container">
                <!-- Gallery + details-->
                <form class="mb-grid-gutter" method="POST" action="{{ route('cart.store') }}" role="form">
                    @csrf
                    <div class="bg-light shadow-lg rounded-3 px-4 py-3 mb-5">
                        <div class="px-lg-3">
                            <div class="row">
                                <!-- Product gallery-->
                                <div class="col-lg-4 pe-lg-0 pt-lg-4">
                                    <div class="product-gallery">
                                        <div class="product-gallery-preview order-sm-2">
                                            @foreach ($productos_fotos as $item)
                                                <div class="product-gallery-preview-item active" id="first"><img
                                                        class="image-zoom"
                                                        src="{{ Storage::disk('productos')->url($item->path) }}"
                                                        data-zoom="img/shop/single/gallery/01.jpg" alt="Product image">
                                                    @if ($item->principal === 1)
                                                        <input type="hidden" value="{{ $item->path }}" id="path"
                                                            name="path">
                                                    @endif
                                                    <div class="image-zoom-pane"></div>
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                                <!-- Product details-->
                                <div class="col-lg-8 pt-4 pt-lg-0">
                                    <div class="product-details ms-auto pb-3">

                                        <input type="hidden" value="{{ $producto->id }}" id="id" name="id">
                                        <input type="hidden" value="{{ $producto->nombre }}" id="name" name="name">
                                        <input type="hidden" value="{{ $producto->precio_venta }}" id="price"
                                            name="price">
                                        <input type="hidden" value="{{ $producto->detalle }}" id="detail"
                                            name="detail">
                                        <input type="hidden" value="{{ $producto->categorias_id }}" id="categorias_id"
                                            name="categorias_id">
                                        <div class="accordion mb-4" id="productPanels">
                                            <div class="accordion-item">
                                                <h3 class="accordion-header"><a class="accordion-button" href="#productInfo"
                                                        role="button" data-bs-toggle="collapse" aria-expanded="true"
                                                        aria-controls="productInfo"><i
                                                            class="ci-announcement text-muted fs-lg align-middle mt-n1 me-2"></i>
                                                        Product info</a></h3>
                                                <div class="accordion-collapse collapse show" id="productInfo"
                                                    data-bs-parent="#productPanels">
                                                    <div class="accordion-body">
                                                        <h6 class="fs-sm mb-2">Composition</h6>
                                                        <ul class="fs-sm ps-4">
                                                            <li>{{ $producto->nombre }}</li>
                                                            <li>{{ $producto->detalle }}</li>
                                                        </ul>
                                                        <h6 class="fs-sm mb-2">Art. No.</h6>
                                                        <ul class="fs-sm ps-4 mb-0">
                                                            <li>{{ $producto->id }}</li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center pb-1">
                                                <label class="form-label" for="weight">WEIGHT</label>
                                            </div>
                                            <select class="form-select" id="weight">
                                                <option value="">Select Weight</option>
                                                <option value="opcion1">Opcion1</option>
                                                <option value="opcion2">Opcion2</option>
                                                <option value="opcion3">Opcion3</option>
                                                <option value="opcion4">Opcion4</option>
                                                <option value="opcion5">Opcion5</option>
                                            </select>
                                        </div>
                                        <div class="mb-1">
                                            <div class="d-flex justify-content-between align-items-center pb-1">
                                                <label class="form-label" for="size">SIZE</label>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <div class="d-flex justify-content-between align-items-center pb-1">
                                                        <label class="form-label" style="font-weight: 400">Width</label>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <input class="form-control" type="text" id="width1"
                                                                placeholder="Feet">
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <input class="form-control" type="text" id="width2"
                                                                placeholder="Inches">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 mb-3">
                                                    <div class="d-flex justify-content-between align-items-center pb-1">
                                                        <label class="form-label" style="font-weight: 400">Height</label>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <input class="form-control" type="text" id="height1"
                                                                placeholder="Feet">
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <input class="form-control" type="text" id="height2"
                                                                placeholder="Inches">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center pb-1">
                                                <label class="form-label" for="weight">WELDING</label>
                                            </div>
                                            <select class="form-select" id="welding">
                                                <option value="">Select Welding</option>
                                                <option value="opcion1">Opcion1</option>
                                                <option value="opcion2">Opcion2</option>
                                                <option value="opcion3">Opcion3</option>
                                                <option value="opcion4">Opcion4</option>
                                                <option value="opcion5">Opcion5</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center pb-1">
                                                <label class="form-label" for="weight">GROMMETS</label>
                                            </div>
                                            <select class="form-select" id="grommets">
                                                <option value="">Select Grommets</option>
                                                <option value="opcion1">Opcion1</option>
                                                <option value="opcion2">Opcion2</option>
                                                <option value="opcion3">Opcion3</option>
                                                <option value="opcion4">Opcion4</option>
                                                <option value="opcion5">Opcion5</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center pb-1">
                                                <label class="form-label" for="weight">ROPE</label>
                                            </div>
                                            <select class="form-select" id="rope">
                                                <option value="">Select Rope</option>
                                                <option value="opcion1">Opcion1</option>
                                                <option value="opcion2">Opcion2</option>
                                                <option value="opcion3">Opcion3</option>
                                                <option value="opcion4">Opcion4</option>
                                                <option value="opcion5">Opcion5</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center pb-1">
                                                <label class="form-label" for="weight">POLE POCKET</label>
                                            </div>
                                            <select class="form-select" id="polepocket">
                                                <option value="">Select Pole Pocket</option>
                                                <option value="opcion1">Opcion1</option>
                                                <option value="opcion2">Opcion2</option>
                                                <option value="opcion3">Opcion3</option>
                                                <option value="opcion4">Opcion4</option>
                                                <option value="opcion5">Opcion5</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center pb-1">
                                                <label class="form-label" for="weight">POLE POCKET SIZE</label>
                                            </div>
                                            <select class="form-select" id="polepocketsize">
                                                <option value="">Select Pole Pocket SIZE</option>
                                                <option value="opcion1">Opcion1</option>
                                                <option value="opcion2">Opcion2</option>
                                                <option value="opcion3">Opcion3</option>
                                                <option value="opcion4">Opcion4</option>
                                                <option value="opcion5">Opcion5</option>
                                            </select>
                                        </div>

                                        <div class="mb-3">
                                            <div class="d-flex justify-content-between align-items-center pb-1">
                                                <label class="form-label" for="weight">QUANTITY</label>
                                            </div>
                                            <input class="form-control" type="numeric" id="quantity" name="quantity"
                                                placeholder="Quantity" required>
                                        </div>

                                        <div class="mb-2">
                                            <div class="row">
                                                <div class="col-md-12 mb-3">
                                                    <div class="row">
                                                        <div class="col-md-6 mb-3">
                                                            <div
                                                                class="d-flex justify-content-between align-items-center pb-1">
                                                                <label class="form-label">CUSTOMER PRICE</label>
                                                            </div>
                                                            <input class="form-control" type="text" id="customerprice"
                                                                placeholder="Customer Price"
                                                                value="{{ $producto->precio_venta }}">
                                                        </div>
                                                        <div class="col-md-6 mb-3">
                                                            <div
                                                                class="d-flex justify-content-between align-items-center pb-1">
                                                                <label class="form-label">UNIT PRICE</label>
                                                            </div>
                                                            <input class="form-control" type="text" id="unitprice"
                                                                placeholder="Unit Price">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="mb-3 d-flex align-items-center">
                                            <button class="btn btn-primary btn-shadow d-block w-100" type="submit"><i
                                                    class="ci-cart fs-lg me-2"></i>Add to Cart</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </main>

        <!-- Back To Top Button--><a class="btn-scroll-top" href="#top" data-scroll><span
                class="btn-scroll-top-tooltip text-muted fs-sm me-2">Top</span><i class="btn-scroll-top-icon ci-arrow-up">
            </i></a>

    </body>
@endsection
