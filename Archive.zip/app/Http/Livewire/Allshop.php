<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Livewire\WithFileUploads;

class Allshop extends Component
{
    use WithFileUploads;

    public $cartCollection = [];
    public $subtotal;
    public $items;
    public $totalInt;
    public $totalDec;
    public $incremento;
    public $quantity;
    public $path;
    public $obs;
    // public $agregar;
    protected $listeners = ['valorAntesDeModificar'];

    // public function valorAntesDeModificar($valor)
    // {
    //     // $this->agregar = $valor;
    //     $id = $valor[1];
    //     $this->incremento = $valor[0];
        
    // }

    public function render()
    {
        $totalAmount = 0;
        $this->cartCollection = \Cart::getContent();
        foreach($this->cartCollection as $item) {

            // $this->items[$item->id] = ["valor" => $item->price, "cantidad" => $item->quantity];
            $totalAmount = $totalAmount + ($item['price'] * $item['quantity']);
        }
        $subtotal = $totalAmount;
        if (strpos($subtotal, '.') !== false) {
            $array = explode('.', $subtotal);
            $entero = $array[0];
            $dec = str_pad($array[1], 2, "0", STR_PAD_RIGHT);
        } else {
            $entero = $subtotal;
            $dec = "00";
        }
        $this->totalInt = $entero;
        $this->totalDec = $dec;

        //, compact('cartCollection')
        return view('livewire.allshop');
    }

    public function variaCantidad($id) {

        $cart = \Cart::getContent(); 
        $incremento = ($this->cartCollection[$id]['quantity'] - $cart[$id]['quantity']);

        \Cart::update(
            $id,
            array(
                'quantity' => $incremento
                ),
            );
        

    }

    public function remove($id)
    {
        \Cart::remove($id);

    }


    public function clearAll() {

        $userid = Auth()->user()->id;
        \Cart::session($userid)->clear();
    
    }

    // public function datos_original($rowId){    
    public function datos_original(){

        // dd($this->path);
        $path = null;
        $obs = null;
        if ($this->path) {
            foreach($this->path as $key => $path) {
                $path = $path->getRealPath();
                if( isset($this->obs[$key]) ) {
                    $obs = $this->obs[$key];
                }

                \Cart::update(
                    $key,
                array( 'options' => [
                        'observation' => $obs,
                        'path' => $path
                    ],
                ));
            }            
        }
// $a = \Cart::getContent();

    return redirect()->route('cart.entrega');
    }

}
