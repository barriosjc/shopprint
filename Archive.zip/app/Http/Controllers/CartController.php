<?php

namespace App\Http\Controllers;

use Stripe;
use App\Models\Cliente;
use App\Models\Producto;
use App\Models\Parametro;
use Darryldecode\Cart\Cart;
use Illuminate\Http\Request;
use App\Models\clientes_sector;
use App\Models\ordenes_compras;
use App\Models\ordenes_compras_det;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\RedirectResponse;

class CartController extends Controller
{
    // public function shop()
    // {
    //     $products = Producto::all();
    //     //dd($products);
    //     return view('shop.carrito')->with(['products' => $products]);
    // }

    public function cart()
    {
        $cartCollection = \Cart::getContent();

        if (!$cartCollection->count()) {
            return back()->with('error_msg', 'No hay productos cargados en el carrito');
        }

        return view('shop.cart')->with(['cartCollection' => $cartCollection]);;
    }

    public function remove(Request $request)
    {
        \Cart::remove($request->id);

        return redirect()->route('cart.index')->with('success_msg', 'Item is removed!');
    }

    public function add(Request $request)
    {
        \Cart::add(array(
            'id' => $request->id,
            'name' => $request->name,
            'price' => $request->price,
            'quantity' => $request->quantity,
            'attributes' => array(
                'image' => $request->path,
                'slug' => $request->detail
            )
        ));

        return redirect()->route('productos.list', $request->categorias_id)->with('success_msg', 'Item Agregado a su Carrito!');
    }

    public function update(Request $request)
    {
        \Cart::update(
            $request->id,
            array(
                'atributes' => array(
                    'entrega' => 'direccion',
                    'entrega_value' => 300.34
                ),
            )
        );

        //dd(\Cart::getContent());

        return redirect()->route('shop.cart')->with('success_msg', 'Cart is Updated!');
    }

    public function clear()
    {
        \Cart::clear();

        return redirect()->route('cart.index')->with('success_msg', 'Car is cleared!');
    }

    public function entrega()
    {
        $cartCollection = \Cart::getContent();
        if ($cartCollection->count()) {
            $costo_envio = Parametro::where('campo', 'costo_envio')->first()->valor;
            $clientes_sector = clientes_sector::where("clientes_id", Auth()->user()->id);
            $clientes_sector = DB::table('clientes_sector')
                ->join('clientes', 'clientes.id', '=', 'clientes_sector.clientes_id')
                ->select('clientes_sector.*', 'clientes.factor_envio')
                ->where('clientes.user_id', Auth()->user()->id)
                ->whereNull('clientes_sector.deleted_at')
                ->get();

            return view('shop.shipping', compact('cartCollection', 'clientes_sector', 'costo_envio'));
        }
        return back()->with('error_msg', 'Debe completar el paso 1');
    }

    public function entrega_save(Request $request) {
        $this->validate($request, [
            'radio' => 'required',
        ]);

        $tipo_envio = $request->radio;
        $cartCollection = \Cart::getContent();
        // al primer item le carga la direccion de entrega
        $item = reset($cartCollection);
        $item = array_keys($item)[0];
// dd($item, explode('|',$request->radio)[0] );
        \Cart::update(
            $item,
            array(
                'entrega' => array(
                    'id' => explode('|',$request->radio)[0] ,
                    'value' => explode('|',$request->radio)[1] 
                ),
            )
        );

        return redirect()->route('cart.pago', $tipo_envio);  
        //return $this->pago($tipo_envio); 
    }

    public function pago ($tipo_envio) {

        $cartCollection = \Cart::getContent();
        $ok_2 = false;
        foreach($cartCollection as $item){
            if( isset($item['entrega']) ) {
                $ok_2 = true;
            }
        }
        if ($ok_2){        
            $cliente = Cliente::where("user_id", Auth()->user()->id)->first();
            if ($cliente->forma_pago_tarjeta) {
                $formaPagos['forma_pago_tarjeta'] = "(Cards) Stripe" ;
            }
            if ($cliente->forma_pago_cheque) {
                $formaPagos['forma_pago_cheque'] = "Check" ;
            }
            if ($cliente->forma_pago_ctacte) {
                $formaPagos['forma_pago_ctacte'] = "Saving Account" ;
            }
            $opcion = "";

            return view('shop.payment', compact('cartCollection', 'formaPagos', 'opcion', 'tipo_envio'));
        }
        return back()->with('error_msg', 'Debe completar el paso 2');
    }

    public function forma_pago(request $request){

        $opcion = $request->radio;

        // Asigna un valor a la variable de sesión 'opcion'
        $_SESSION['opcion'] = 'valor_que_quieres_asignar';

        return back()->with(compact("opcion"))->withInput();
    }

    public function stripePost(Request $request, string $opcion): RedirectResponse
    {
        $total = \Cart::getTotal();

        Stripe\Stripe::setApiKey(config('services.stripe.secret'));
      
        $resultado = Stripe\Charge::create ([
                "amount" => $total * 100,
                "currency" => "usd",
                "source" => $request->stripeToken,
                "description" => "Test payment from itsolutionstuff.com." 
        ]);

        $cartCollection = \Cart::getContent();
        //obtengo direcc de envio y costo
        $entrega = ['id' => null, 'value' => null];
        foreach ($cartCollection as $elemento) {
            // dd($elemento, isset( $elemento['entrega'] ));  
            if(isset(  $elemento['entrega'] )) {
                $entrega = $elemento['entrega'];
                break;
            } 
        }
     
        $orden = new ordenes_compras;
        $orden->users_id = Auth()->user()->id;
        $orden->forma_pago = $opcion;
        $orden->tipo_envio = $entrega['id'];
        $orden->costo_envio = $entrega['value'];
        $orden->estado = 1;
        $orden->stripe_id = $resultado->id;
        $orden->total_descuento = 0;
        $orden->total = $total;
        $orden->save();

        foreach($cartCollection as $item ){
            $oc_det = new ordenes_compras_det;
            $oc_det->ordenes_compras_id = $orden->id;
            $oc_det->productos_id = $item->id;
            $oc_det->obs = isset($item['options']['observation']) ? $item['options']['observation'] : null;
            $oc_det->path = isset($item['options']['path']) ? $item['options']['path'] : null;
            $oc_det->cantidad = $item->quantity;
            $oc_det->precio = $item->price;
            $oc_det->descuento_id = null;
            $oc_det->save();
        }


        \Cart::clear();
        \cart::session(Auth()->user()->id)->clear();
                
        return redirect()->route("cart.review", $orden->id)
                ->with('success_msg', 'Payment successful!');
    }

    public function review($id){

        if ($id > 0) {
            $orden_compra = ordenes_compras::v_orden_compra($id)->first();
            $ordenes_compras_det = ordenes_compras_det::v_ordenes_compras_det($id)->get();

            return view('shop.review', compact("orden_compra", 'ordenes_compras_det'));
        }
        return back()->with('error_msg', 'Solo se ve el resumen luego de hacer el pago, en su perfil ve las Ordenes de compras');
    }
}
