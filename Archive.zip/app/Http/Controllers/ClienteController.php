<?php

namespace App\Http\Controllers;

use DateTime;
use Exception;
use App\Models\User;
use App\Models\Cliente;
use App\Models\Descuento;
use App\Models\Parametro;
use Illuminate\Http\Request;
use App\Models\clientes_sector;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use App\Models\clientes_datos_facturacion;

/**
 * Class ClienteController
 * @package App\Http\Controllers
 */
class ClienteController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $clientes = Cliente::paginate();

        return view('cliente.index', compact('clientes'))
            ->with('i', (request()->input('page', 1) - 1) * $clientes->perPage());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($origen)
    {
        $cliente = new Cliente();
        $user = new User();
        $usuarios = User::v_empleados()->get();
        $descuentos = Descuento::get();
        $sectores = Parametro::where("campo", 'sector_entrega')->get();
        $datos_factu = new clientes_datos_facturacion;
        $cli_sector = new clientes_sector;

        if($origen === 'register') {
            $view = 'auth.register';
        } else {
            $view = 'cliente.create';
        }

        return view($view, compact('cliente', 'descuentos', 'usuarios', 'user', 'sectores', 'datos_factu', 'cli_sector'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $origen)
    {
        $validated = $request->validate([
            'contacto' => 'required',
            'nombre_fantasia' => 'required',
            'form_path' => 'required',
            'email' => ['required','email',Rule::unique('clientes')]
        ],
        ['email.unique' => 'The email has already been registered. If you had already registered previously, log in and recover your password.',
        'form_path' => 'You must choice the form file.']
        );

        request()->validate(clientes_datos_facturacion::$rules);
        request()->validate(clientes_sector::$rules);

        DB::beginTransaction(); // Inicia la transacción
        try {
        $user = new user;
        $user->name = $request->contacto;
        $user->email = $request->email;
        $user->password = Hash::make('12345678');
        $user->save();

        $cliente = new Cliente;
        $cliente->user_id = $user->id;
        $cliente->contacto = $request->contacto;
        $cliente->nombre_fantasia = $request->nombre_fantasia;
        $cliente->descuentos_id = isset($request->descuentos_id) ? $request->descuentos_id : null;
        $cliente->users_id_aprobo = isset($request->users_id_aprobo) ? $request->users_id_aprobo : null;

        $originalName = $request->file('form_path')->getClientOriginalName();
        $path = $originalName;
        $path = Storage::disk('clientes')->put("", $request->file('form_path'));
        $cliente->form_path = $path;
        
        $cliente->email = $request->email;
        if ($origen === 'register') {
            $cliente->fecha_aprobo = null; 
            $cliente->forma_pago_tarjeta = isset($request->tarjeta) ? 1 : 0;
            $cliente->forma_pago_cheque = isset($request->cheque) ? 1 : 0;
            $cliente->forma_pago_ctacte = isset($request->ctacte) ? 1 : 0;
        }else {
            $cliente->fecha_aprobo = date("Y-m-d H:i"); 
            $cliente->forma_pago_tarjeta = 1;
        }
        $cliente->save();

        $facturacion = new clientes_datos_facturacion;
        $facturacion->clientes_id = $cliente->id;
        $facturacion->cuit = $request->cuit;
        $facturacion->direccion = $request->direccion;
        $facturacion->razon_social  = $request->razon_social;
        $facturacion->save();

        $sector = new clientes_sector;
        $sector->clientes_id = $cliente->id;
        $sector->sectores_id = $request->sectores_id;
        $sector->sector_email = isset($request->sector_email) ? $request->sector_email : null;
        $sector->sector_telef =  isset($request->sector_telef) ? $request->sector_telef : null;
        $sector->sector_direccion = $request->sector_direccion;
        $sector->sector_cp = $request->sector_cp;
        $sector->save();
        
        DB::commit();

        return redirect()->route('clientes.index')
            ->with('success', 'Cliente created successfully.');

        } catch (Exception $e) {
            // Si ocurre algún error, revierte la transacción
            DB::rollBack();
    
            return redirect()->back()->with('error', 'Error al guardar los datos del cliente cliente ' . $e->getMessage());
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $cliente = Cliente::find($id);

        return view('cliente.show', compact('cliente'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id){

        $cliente = Cliente::find($id);
        $user = User::where('email', $cliente->email)->first();
        $usuarios = User::v_empleados()->get();
        $descuentos = Descuento::get();
        $sectores = Parametro::where("campo", 'sector_entrega')->get();
        $datos_factu = clientes_datos_facturacion::where('clientes_id', $id)->first();

        $cli_sector = clientes_sector::where('clientes_id', $id)->first();

        return view('cliente.edit', compact('cliente', 'descuentos', 'usuarios', 'user', 'sectores', 'datos_factu', 'cli_sector'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  Cliente $cliente
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Cliente $cliente)
    {
        $validated = $request->validate([
            'contacto' => 'required',
            'nombre_fantasia' => 'required',
            'form_path' => Rule::requiredIf(fn () => $request->form_path_text),
            'email' => ['required', 'email', Rule::unique('clientes')->ignore($cliente->id)]

        ],
        ['email.unique' => 'The email has already been registered. If you had already registered previously, log in and recover your password.',
        'form_path' => 'You must choice the form file.']
        );
        
        request()->validate(clientes_datos_facturacion::$rules);
        request()->validate(clientes_sector::$rules);

        DB::beginTransaction(); // Inicia la transacción
        try {
        $cliente->contacto = $request->contacto;
        $cliente->nombre_fantasia = $request->nombre_fantasia;
        $cliente->descuentos_id = isset($request->descuentos_id) ? $request->descuentos_id : null;
        $cliente->users_id_aprobo = isset($request->users_id_aprobo) ? $request->users_id_aprobo : null;
        $cliente->fecha_aprobo = isset($request->fecha_aprobo) ? $request->fecha_aprobo : date("Y-m-d H:m");
        if($request->hasFile('form_path')){
            $originalName = $request->file('form_path')->getClientOriginalName();
            $path = $originalName;
            $path = Storage::disk('clientes')->put("", $request->file('form_path'));
            $cliente->form_path = $path;
        }
        $cliente->contacto = $request->contacto;
        $cliente->email = $request->email;
        $cliente->forma_pago_tarjeta = isset($request->tarjeta) ? 1 : 0;
        $cliente->forma_pago_cheque = isset($request->cheque) ? 1 : 0;
        $cliente->forma_pago_ctacte = isset($request->ctacte) ? 1 : 0;
        $cliente->save();

        $user = User::where('email', $cliente->email)->first();
        $user->name = $request->contacto;
        $user->email = $request->email;
        $user->save();

        $facturacion = clientes_datos_facturacion::where('clientes_id', $cliente->id)->first();
        $facturacion->clientes_id = $cliente->id;
        $facturacion->cuit = $request->cuit;
        $facturacion->direccion = $request->direccion;
        $facturacion->razon_social  = $request->razon_social;
        $facturacion->save();

        $sector = clientes_sector::where('clientes_id', $cliente->id)->first();
        $sector->clientes_id = $cliente->id;
        $sector->sectores_id = $request->sectores_id;
        $sector->sector_email = isset($request->sector_email) ? $request->sector_email : null;
        $sector->sector_telef = isset($request->sector_telef) ? $request->sector_telef : null;
        $sector->sector_direccion = $request->sector_direccion;
        $sector->sector_cp = $request->sector_cp;
        $sector->save();
        
        DB::commit();

        return redirect()->route('clientes.index')
            ->with('success', 'Cliente created successfully.');

        } catch (Exception $e) {
            // Si ocurre algún error, revierte la transacción
            DB::rollBack();
    
            return redirect()->back()->with('error', 'Error al actualizar los datos del cliente cliente ' . $e->getMessage());
        }
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $cliente = Cliente::find($id)->delete();

        return redirect()->route('clientes.index')
            ->with('success', 'Cliente deleted successfully');
    }
}
