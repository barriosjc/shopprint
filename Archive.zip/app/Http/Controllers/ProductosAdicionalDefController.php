<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use App\Models\Parametro;
use App\Models\ProductosAdicionalDef;
use Illuminate\Http\Request;

/**
 * Class ProductosAdicionalDefController
 * @package App\Http\Controllers
 */
class ProductosAdicionalDefController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $ProductosAdicionalDef = ProductosAdicionalDef::paginate();

        return view('productos-adicional-def.index', compact('ProductosAdicionalDef'))
            ->with('i', (request()->input('page', 1) - 1) * $ProductosAdicionalDef->perPage());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $productosAdicionalDef = new ProductosAdicionalDef();
        $adic_tipo = Parametro::where('campo', 'prod_adic_tipo')->get();
        $categorias = Categoria::all();

        return view('productos-adicional-def.create', compact('productosAdicionalDef', 'adic_tipo', 'categorias'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        request()->validate(ProductosAdicionalDef::$rules);

        $productosAdicionalDef = ProductosAdicionalDef::create($request->all());

        return redirect()->route('ProductosAdicionalDef.index')
            ->with('success', 'ProductosAdicionalDef created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $productosAdicionalDef = ProductosAdicionalDef::find($id);

        return view('productos-adicional-def.show', compact('productosAdicionalDef'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $productosAdicionalDef = ProductosAdicionalDef::find($id);

        return view('productos-adicional-def.edit', compact('productosAdicionalDef'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  ProductosAdicionalDef $productosAdicionalDef
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProductosAdicionalDef $productosAdicionalDef)
    {
        request()->validate(ProductosAdicionalDef::$rules);

        $productosAdicionalDef->update($request->all());

        return redirect()->route('ProductosAdicionalDef.index')
            ->with('success', 'ProductosAdicionalDef updated successfully');
    }

    /**
     * @param int $id
     * @return \Illuminate\Http\RedirectResponse
     * @throws \Exception
     */
    public function destroy($id)
    {
        $productosAdicionalDef = ProductosAdicionalDef::find($id)->delete();

        return redirect()->route('ProductosAdicionalDef.index')
            ->with('success', 'ProductosAdicionalDef deleted successfully');
    }
}
