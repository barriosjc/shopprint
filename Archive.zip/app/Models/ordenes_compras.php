<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $users_id
 * @property string $forma_pago
 * @property string $tipo_envio
 * @property string $costo_envio
 * @property int $estado
 * @property string $stripe_id
 * @property float $total_descuento
 * @property string $created_at
 * @property string $updated_at
 * @property string $deleted_at
 */
class ordenes_compras extends Model
{
    /**
     * @var array
     */
    protected $fillable = ['users_id', 'forma_pago', 'tipo_envio', 'costo_envio', 
    'estado', 'stripe_id', 'total_descuento', 
    'total', 'created_at', 'updated_at', 'deleted_at'];



    public static function v_orden_compra($orden_id) {

        $resu = ordenes_compras::query()
        ->join('clientes','users_id', 'ordenes_compras.users_id')
        ->leftjoin('clientes_sector','clientes_sector.id', 'tipo_envio')
        ->select(['ordenes_compras.*', 'nombre_fantasia','sector_direccion', 'sector_cp'])
        ->where( 'ordenes_compras.id', $orden_id)
        ->orderby('ordenes_compras.id', 'asc');
        
        return $resu;
    }
}
