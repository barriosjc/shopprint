<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Descuento
 *
 * @property $id
 * @property $descripcion
 * @property $porcentaje
 * @property $orden
 * @property $vigencia_desde
 * @property $vigencia_hasta
 * @property $created_at
 * @property $updated_at
 * @property $deleted_at
 *
 * @property Cliente[] $clientes
 * @property Producto[] $productos
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class Descuento extends Model
{
    use SoftDeletes;

    static $rules = [
		'descripcion' => 'required',
		'porcentaje' => 'required',
		'orden' => 'required',
		'vigencia_desde' => 'required',
		'vigencia_hasta' => 'required',
    ];

    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['descripcion','porcentaje','orden','vigencia_desde','vigencia_hasta'];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function clientes()
    {
        return $this->hasMany('App\Models\Cliente', 'descuentos_id', 'id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function productos()
    {
        return $this->hasMany('App\Models\Producto', 'descuentos_id', 'id');
    }
    

}
