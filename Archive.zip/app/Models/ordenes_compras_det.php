<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property int $ordenes_compras_id
 * @property int $productos_id
 * @property int $cantidad
 * @property int $descuento_id
 * @property float $precio
 * @property string $created_at
 * @property string $updated_at
 * @property string $deleted_at
 */
class ordenes_compras_det extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'ordenes_compras_det';

    /**
     * @var array
     */
    protected $fillable = ['ordenes_compras_id', 'productos_id', 'cantidad', 'descuento_id', 'precio', 
                            'path', 'obs', 'user_id', 'created_at', 'updated_at', 'deleted_at'];

    public static function v_ordenes_compras_det ($orden_id) {

        $resu = ordenes_compras_det::query()
        ->join('productos','productos.id', 'ordenes_compras_det.productos_id')
        ->join('productos_fotos','productos_fotos.productos_id', 'ordenes_compras_det.productos_id')
        ->select(['ordenes_compras_det.*', 'productos_fotos.path', 'productos.nombre', 'productos.detalle', 'productos.slug'])
        ->where( 'ordenes_compras_id', $orden_id)
        ->where('principal', 1)
        ->orderby('ordenes_compras_det.id', 'asc')
        ->whereNull('productos_fotos.deleted_at');
        
        return $resu;
    }
}
