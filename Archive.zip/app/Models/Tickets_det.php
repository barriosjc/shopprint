<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property integer $tickets_id
 * @property string $insidente
 * @property int $users_id
 * @property int $users_id_rta
 * @property string $original_path
 * @property string $created_at
 * @property string $updated_at
 * @property string $deleted_at
 * @property string $obs
 * @property int $estado_id
 * @property Ticket $ticket
 */
class Tickets_det extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'tickets_det';

    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['tickets_id', 'insidente', 'users_id', 'users_id_rta', 'original_path', 'created_at', 'updated_at', 'deleted_at', 'obs', 'estado_id'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function ticket()
    {
        return $this->belongsTo('App\Ticket', 'tickets_id');
    }
}
