<?php

namespace App\Models;

use Illuminate\Validation\Rule;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Cliente
 *
 * @property $id
 * @property $contacto
 * @property $nombre_fantasia
 * @property $created_at
 * @property $updated_at
 * @property $deleted_at
 * @property $descuentos_id
 * @property $users_id_aprobo
 * @property $fecha_aprobo
 * @property $form_path
 *
 * @property ClientesDatosFacturacion[] $clientesDatosFacturacions
 * @property ClientesFormasPago[] $clientesFormasPagos
 * @property ClientesSector[] $clientesSectors
 * @property Descuento $descuento
 * @property Pedido[] $pedidos
 * @property User $user
 * @package App
 * @mixin \Illuminate\Database\Eloquent\Builder
 */
class Cliente extends Model
{
    use SoftDeletes;


    protected $perPage = 20;

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['contacto','nombre_fantasia','descuentos_id','users_id_aprobo','fecha_aprobo','form_path',
                            'forma_pago_tarjeta', 'forma_pago_cheque', 'forma_pago_ctacte'];

    public function getFechaAproboAttribute($value)
    {
        $resu = '';
        if (!empty($value)) {
            $resu = date('d/m/Y', strtotime($value));
        }

        return $resu;
    }
                            
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function clientesDatosFacturacions()
    {
        return $this->hasMany('App\Models\ClientesDatosFacturacion', 'clientes_id', 'id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function clientesFormasPagos()
    {
        return $this->hasMany('App\Models\ClientesFormasPago', 'clientes_id', 'id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function clientesSectors()
    {
        return $this->hasMany('App\Models\ClientesSector', 'clientes_id', 'id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function descuento()
    {
        return $this->hasOne('App\Models\Descuento', 'id', 'descuentos_id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function pedidos()
    {
        return $this->hasMany('App\Models\Pedido', 'clientes_id', 'id');
    }
    
    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function user()
    {
        return $this->hasOne('App\Models\User', 'id', 'users_id_aprobo');
    }
    

}
