<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * @property integer $id
 * @property int $users_id
 * @property int $ordenes_compras_id
 * @property int $ordenes_compras_det_id
 * @property int $estado_id
 * @property string $created_at
 * @property string $updated_at
 * @property string $deleted_at
 * @property TicketsDetalle[] $ticketsDetalles
 */
class Tickets extends Model
{
    /**
     * The table associated with the model.
     * 
     * @var string
     */
    protected $table = 'tickets';

    /**
     * The "type" of the auto-incrementing ID.
     * 
     * @var string
     */
    protected $keyType = 'integer';

    /**
     * @var array
     */
    protected $fillable = ['users_id', 'ordenes_compras_id', 'ordenes_compras_det_id', 'estado_id', 'created_at', 'updated_at', 'deleted_at'];

    /**
     * @return \Illuminate\Database\Eloquent\Relations\HasMany
     */
    public function ticketsDetalles()
    {
        return $this->hasMany('App\TicketsDetalle', 'tickets_id');
    }
}
