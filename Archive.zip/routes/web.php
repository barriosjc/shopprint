<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\CartController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\CategoriaController;
use App\Http\Controllers\DescuentoController;
use App\Http\Controllers\ParametroController;
use App\Http\Controllers\FormasPagoController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\ProductosFotoController;
use App\Http\Controllers\seguridad\RoleController;
use App\Http\Controllers\seguridad\ProfileController;
use App\Http\Controllers\seguridad\UsuarioController;
use App\Http\Controllers\Auth\ResetPasswordController;
use App\Http\Controllers\seguridad\PermisosController;
use App\Http\Controllers\ProductosAdicionalDefController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();

Route::get('/wellcome', function () {
    return view('wellcome');
});

Route::get('login/restablecer'            , [ResetPasswordController::class, 'restablecer'])->name('login.restablecer');
Route::post('login/email'                 , [ResetPasswordController::class, 'email'])->name('login.email');
//Route::get('login/register', [RegisterController::class, 'create'])->name('login.register');
Route::post('clientes/{origen}'           , [ClienteController::class, 'store'])->name('clientes.store');
Route::get('clientes/create/{origen}'     , [ClienteController::class, 'create'])->name('clientes.create');

Route::group(['middleware' => 'auth'], function () {

    Route::get('/', [HomeController::class, 'index'])->name('home');
    //Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
//carrito

    Route::get('cart/entrega'              , [CartController::class, 'entrega'])->name('cart.entrega');
    Route::post('cart/entrega/store'       , [CartController::class, 'entrega_save'])->name('cart.entrega.save');
    Route::get('cart/pago/{tipo}'          , [CartController::class, 'pago'])->name('cart.pago');
    Route::post('cart/pago/formapago'          , [CartController::class, 'forma_pago'])->name('cart.formapago');
    Route::post('cart/pago/envio/{op}'         , [CartController::class, 'stripePost'])->name('cart.post');
    Route::post('cart/pago/store'         , [CartController::class, 'pago_save'])->name('cart.pago.save');
    Route::get('cart/review/{id}'              , [CartController::class, 'review'])->name('cart.review');

    Route::get('cart'                     , [CartController::class, 'cart'])->name('cart.index');
    Route::post('cart/add'                , [CartController::class, 'add'])->name('cart.store');
    Route::post('cart/update'             , [CartController::class, 'update'])->name('cart.update');
    Route::post('cart/remove'             , [CartController::class, 'remove'])->name('cart.remove');
    Route::post('cart/clear'              , [CartController::class, 'clear'])->name('cart.clear');

    //clientes
    Route::get('clientes'                     , [ClienteController::class, 'index'])->name('clientes.index');
    Route::get('clientes/{producto}'          , [ClienteController::class, 'show'])->name('clientes.show');
    Route::patch('clientes/{producto}'        , [ClienteController::class, 'update'])->name('clientes.update');
    Route::delete('clientes/{producto}'       , [ClienteController::class, 'destroy'])->name('clientes.destroy');
    Route::get('clientes/{producto}/edit'     , [ClienteController::class, 'edit'])->name('clientes.edit');

//Route::group(['middleware' => ['can:abm clientes']], function () {    
    Route::resource('parametros'           , ParametroController::class);
    Route::resource('categorias'           , CategoriaController::class);
    Route::resource('descuentos'           , DescuentoController::class);
    Route::resource('ProductosAdicionalDef', ProductosAdicionalDefController::class);
    Route::resource('formasPagos'          , FormasPagoController::class);

    //productos
    Route::get('productos/index/{categoria}'    , [ProductoController::class, 'index'])->name('productos.index');
    Route::post('productos'                     , [ProductoController::class, 'store'])->name('productos.store');
    Route::get('productos/create/{categoria}'   , [ProductoController::class, 'create'])->name('productos.create');
    Route::get('productos/{producto}'           , [ProductoController::class, 'show'])->name('productos.show');
    Route::patch('productos/{producto}'         , [ProductoController::class, 'update'])->name('productos.update');
    Route::delete('productos/{producto}'        , [ProductoController::class, 'destroy'])->name('productos.destroy');
    Route::get('productos/{producto}/edit'      , [ProductoController::class, 'edit'])->name('productos.edit');
   
    //productos vistas fromt
    Route::get('productos/list/{categoria}'     , [ProductoController::class, 'list'])->name('productos.list');
    Route::get('productos/detail/{id}'          , [ProductoController::class, 'detalle'])->name('productos.detalle');
    
    //fotos
    Route::get('productos/fotos/index/{producto}'          , [ProductosFotoController::class, 'index'])->name('productos.fotos.index');
    Route::post('productos/fotos'                          , [ProductosFotoController::class, 'store'])->name('productos.fotos.store');
    Route::get('productos/fotos/create/{producto}'         , [ProductosFotoController::class, 'create'])->name('productos.fotos.create');
    Route::get('productos/fotos/{producto}'                , [ProductosFotoController::class, 'show'])->name('productos.fotos.show');
    Route::patch('productos/fotos/{producto}'              , [ProductosFotoController::class, 'update'])->name('productos.fotos.update');
    Route::delete('productos/fotos/{id}/{producto}'        , [ProductosFotoController::class, 'destroy'])->name('productos.fotos.destroy');
    Route::get('productos/fotos/{producto}/edit'           , [ProductosFotoController::class, 'edit'])->name('productos.fotos.edit');

    //usuarios y seguridad
    Route::resources([
        'usuario' => UsuarioController::class,
        'roles' => RoleController::class,
        'permisos' => permisosController::class,
    ]);


    Route::get('profile/{id}/editar'  , [ProfileController::class, 'index'])->name('profile');
    Route::post('foto/profile/guardar', [ProfileController::class, 'foto'])->name('profile.foto');
    Route::post('profile'             , [ProfileController::class, 'save'])->name('profile.save');
    Route::get('profile/{id}/readonly', [ProfileController::class, 'readonly'])->name('profile.readonly');

    Route::get('front/profile'  , [ProfileController::class, 'profile'])->name('front.profile');
    
    
    Route::get('usuario/{id}/roles/{rolid}/{tarea}'   , [UsuarioController::class, 'roles']);
    Route::get('usuario/{id}/roles'                   , [UsuarioController::class, 'roles'])->name('usuarios.grupos');
    Route::get('usuario/{id}/permisos/{perid}/{tarea}', [UsuarioController::class, 'permisos']);
    Route::get('usuario/{id}/permisos'                , [UsuarioController::class, 'permisos']);

    Route::get('roles/{id}/permisos/{perid}/{tarea}', [RoleController::class, 'permisos']);
    Route::get('roles/{id}/permisos'                , [RoleController::class, 'permisos']);
    Route::get('roles/{id}/usuarios/{usuid}/{tarea}', [RoleController::class, 'usuarios']);
    Route::get('roles/{id}/usuarios'                , [RoleController::class, 'usuarios']);

    Route::get('permisos/{id}/usuarios/{usuid}/{tarea}', [PermisosController::class, 'usuarios']);
    Route::get('permisos/{id}/usuarios'                , [PermisosController::class, 'usuarios'])->name('permisos.usuarios');
    Route::get('permisos/{id}/roles/{rolid}/{tarea}'   , [PermisosController::class, 'roles']);
    Route::get('permisos/{id}/roles'                   , [PermisosController::class, 'roles'])->name('permisos.grupos');

});    
